-- Colors
-- vim.o.background = 'dark'
vim.o.termguicolors = true
vim.o.winblend = 0
vim.o.wildoptions = 'pum'
vim.o.pumblend = 5
