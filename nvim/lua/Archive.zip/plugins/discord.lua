return {
    'lpturmel/discord.nvim',
    config = function()
        local discord = require('discord')

        discord.setup()
    end
}
